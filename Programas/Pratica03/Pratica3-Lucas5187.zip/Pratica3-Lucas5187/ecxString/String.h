/*----------------- File: .cpp ----------------------+
|DESCRICAO DO ARQUIVO
|
|
|
|
|
| Implementado por “Lucas Alves” em 06/04/2018
|
+-----------------------------------------------------+ */


#ifndef STRING_H
#define STRING_H

class String{
public:
void digitaString();
char *imprimeString();
int comprimento();

private:
char text[100];

};
#endif

